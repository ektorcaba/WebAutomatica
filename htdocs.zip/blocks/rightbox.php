<?php


    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=primevideo&banner=1QKGBKJKQHE624VYK8R2&f=ifr&linkID=eeca4198cead24bd29b3274b97087308&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';

    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=prime_video&banner=1AMWS5A104Q9ZCXDQT82&f=ifr&linkID=eab8db9cc2dc57eaaf59c8ed538511ce&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=amu&banner=1FMQKNFMD092SHJ73MR2&f=ifr&linkID=03acae1776fe0adf1cba8d0176a637a7&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=audiblees&banner=09KA4RD60DQ7T021KC02&f=ifr&linkID=2ca11137197d075f7ea3f75b29fe29ce&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=primevideo&banner=0NRNZZK80JY2Z2M2WGG2&f=ifr&linkID=015276f2982856658489c0b787128cfe&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=primevideo&banner=17BVA3WN4257883ER3G2&f=ifr&linkID=78658093b8c94342c133c4d5a85f1da7&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';

    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=primevideo&banner=0531HET7ZXW8GSAQSQR2&f=ifr&linkID=42dbab2a2d873ab603d5fa086873d2ee&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=premium&banner=1D9E5EF28RHYM8HGN8R2&f=ifr&linkID=07abcc9954340181bd2a6c887e4eec31&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>'; 
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=esgifting&banner=09P9EHEKSEP1HPSDRXG2&f=ifr&linkID=2f74e619cbae7d2453eb5099f97962b9&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>'; 
    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=esdiscover&banner=1HZ32C98V46GGJ6THTR2&f=ifr&linkID=4ac82f325d788190f7d782e869339d5d&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>'; 

    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=esfavorites&banner=0A72HD70QQ5R3RGHA202&f=ifr&linkID=492c6b9078b46c1a610cb3683b947fbb&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';

    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=lista_bodas&banner=0NY09P7NVWH28TXG7M02&f=ifr&linkID=b263bc4a8d1215b80c44b47ee231d842&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';


    $rbanner[] = '<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=14&l=ur1&category=baby&banner=1WQFJQJ4RRRB69XPNEG2&f=ifr&linkID=640badee2e9e089436462e9ac253611b&t=ektorcaba-21&tracking_id=ektorcaba-21" width="160" height="600" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>';


    echo $rbanner[rand(0,(count($rbanner)-1))];

?>